const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const outputPath = path.join(__dirname, '..', 'Drodul_Phendey_Ling_1_Week_Project_Timeline.pdf');
const doc = new PDFDocument({
  size: 'A4',
  margins: { top: 45, bottom: 45, left: 45, right: 45 },
  bufferPages: true
});

const writeStream = fs.createWriteStream(outputPath);
doc.pipe(writeStream);

// Colors
const MAROON = '#4A0E17';
const GOLD = '#B8860B';
const DARK_TEXT = '#2D3748';
const MUTED_TEXT = '#4A5568';
const LIGHT_BG = '#FAF5F0';
const BORDER_COLOR = '#E2D9CE';

// Helper for section headings
function addSectionHeader(title, dayNumber) {
  doc.moveDown(0.6);
  
  // Day badge + Title
  const startY = doc.y;
  doc.rect(45, startY, 505, 22).fill(LIGHT_BG).stroke(BORDER_COLOR);
  
  doc.fillColor(MAROON)
     .font('Helvetica-Bold')
     .fontSize(11)
     .text(`DAY ${dayNumber}: ${title.toUpperCase()}`, 55, startY + 6);
  
  doc.moveDown(0.8);
}

function addBullet(title, description) {
  const bulletX = 55;
  const textX = 70;
  const currentY = doc.y;
  
  doc.fillColor(GOLD).fontSize(10).text('•', bulletX, currentY);
  
  doc.fillColor(DARK_TEXT)
     .font('Helvetica-Bold')
     .fontSize(9.5)
     .text(title + ': ', textX, currentY, { continued: true });
     
  doc.fillColor(MUTED_TEXT)
     .font('Helvetica')
     .fontSize(9.5)
     .text(description, { lineGap: 2 });
     
  doc.moveDown(0.3);
}

// ==========================================
// 1. COVER / HEADER SECTION
// ==========================================
doc.rect(45, 45, 505, 75).fill(MAROON);

doc.fillColor('#FFFFFF')
   .font('Helvetica-Bold')
   .fontSize(16)
   .text('DRODUL PHENDEY LING FOUNDATION', 55, 58, { align: 'center' });

doc.fillColor('#D4AF37')
   .font('Helvetica-Bold')
   .fontSize(11)
   .text('1-WEEK FULL PROJECT DELIVERY TIMELINE & ROADMAP', 55, 80, { align: 'center' });

doc.fillColor('#FDF6E2')
   .font('Helvetica')
   .fontSize(8.5)
   .text('Full-Stack Platform: Public Website • Devotee User Portal • Super Admin ERP (MySQL / Node / React)', 55, 98, { align: 'center' });

doc.y = 135;

// ==========================================
// DAY 1
// ==========================================
addSectionHeader('Architecture, Database Modeling & Foundation Setup', '1');
addBullet('Full-Stack Stack Setup', 'Vite + React 18 frontend, Node.js + Express backend, MySQL 8.0 connection pool with transaction wrappers.');
addBullet('Database Schema (db/schema.sql)', 'Engineered 30 relational database tables covering Auth, Roles, Permissions, Donations, Accounts, Inventory, HRM, Payroll, Blog, Learning, and Gallery.');
addBullet('Seed Data (db/seed.sql)', 'Pre-seeded 5 system roles (Super Admin, Accountant, Staff, HR, Devotee), bcrypt credentials, chart of accounts, and initial store items.');

// ==========================================
// DAY 2
// ==========================================
addSectionHeader('Authentication, Security & Server-Enforced RBAC', '2');
addBullet('Strict 3-Portal Separation', 'Public Website (/), Unified Devotee User Panel (/user), and Single Admin ERP Shell (/admin) with server-enforced role restrictions.');
addBullet('Isolated Admin Login (/admin/login)', 'Dedicated administrative login route with server-side permission checks. Super Admin provisions staff accounts inside Users & Roles.');
addBullet('Security Sanitization', 'Eliminated all demo credentials, prefilled inputs, and 1-click test buttons. Configured JWT middleware and comprehensive audit logging.');

// ==========================================
// DAY 3
// ==========================================
addSectionHeader('Donations, Multi-Currency Gateways & 80G PDF Engine', '3');
addBullet('Donation Engine', 'Support for INR, BTN, USD, EUR, and GBP for one-time offerings and recurring monthly pledges.');
addBullet('Payment Gateways', 'Integrated Razorpay and Stripe with webhook signature verification and idempotency log protection.');
addBullet('Automated 80G PDF Receipts', 'Built-in PDFKit generator creating official tax-deductible receipts with seal, signature, and automatic email dispatch via Nodemailer.');

// ==========================================
// DAY 4
// ==========================================
addSectionHeader('Accounts, Vouchers, Expenses & Inventory Store ERP', '4');
addBullet('Accounts & Finance ERP', 'Real-time income vs. expense dashboards, growth tracking, payment vouchers (VCH-YYYY-XXXXXX), and bank reconciliation.');
addBullet('Expense Approval Workflow', 'Multi-level claims review (pending -> approved / rejected -> paid) with mandatory audit reason capture.');
addBullet('Inventory Store Management', 'Stock In (GRN) and Stock Out (Usage Requisition) tracking with FIFO unit costing and real-time Low Stock alerts.');

// ==========================================
// DAY 5
// ==========================================
addSectionHeader('HRM, Biometric Attendance, Payroll Runs & CMS', '5');
addBullet('HRM & Leave Tracking', 'Staff directory, designations, attendance logs, and leave approval workflows.');
addBullet('1-Click Monthly Payroll Engine', 'Automated gross pay, tax deductions, net pay calculation, printable PDF salary slips, and casual labor wage registry.');
addBullet('Public Learning & Dharma CMS', 'Video discourse library supporting YouTube, Vimeo, and direct MP4 video uploads (up to 100MB). Monastery blog with SEO slugs and prayer request desk.');

// ==========================================
// DAY 6
// ==========================================
addSectionHeader('Authentic Bhutanese Theming, UI/UX & Responsive Design', '6');
addBullet('Traditional Bhutanese Styling', 'Royal temple maroon (#4A0E17, #7E1929), saffron gold (#D4AF37), and Dzongkha calligraphy headers (font-tibetan).');
addBullet('Curated Bhutan Monastic Media', 'Dochula Pass 108 Chortens Stupa, Punakha Dzong, Paro Taktsang (Tiger\'s Nest), Shedra monk scholars in robes, and 108 glowing butter lamps.');
addBullet('Resilient Media Loading', 'Universal onError fallback handlers across all image elements preventing broken placeholders.');

// ==========================================
// DAY 7
// ==========================================
addSectionHeader('System Audit, Production Hardening & VPS Go-Live', '7');
addBullet('124-Point Automated Audit Suite', '124 / 124 Checks Passed (100%) across 13 Public Pages, 2 User Panel views, 23 Admin modules, 19 Controllers, and 30 DB tables.');
addBullet('Server-Ready Deployment Files', 'ecosystem.config.js for PM2 cluster mode, nginx.conf.example for reverse proxy with 100MB body limits, and .env.example configuration.');
addBullet('VPS Live Verification', 'Full end-to-end verification of Public Portal, Devotee Panel, and Admin ERP.');

// ==========================================
// SUMMARY TABLE
// ==========================================
doc.moveDown(0.8);
const tableTop = doc.y;

doc.rect(45, tableTop, 505, 18).fill(MAROON);
doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(9).text('FINAL PROJECT DELIVERABLES SUMMARY', 55, tableTop + 5);

const rows = [
  ['Portals', '3 Portals (Public Website, Devotee User Panel, Admin ERP Shell)'],
  ['Backend', 'Node.js + Express API with 19 Controllers and server-enforced RBAC'],
  ['Database', '30 Relational MySQL Tables with schema, seed data, and foreign keys'],
  ['Media', 'Authentic Bhutan & Thimphu monastic imagery with onError fallbacks'],
  ['Testing', '124-point automated test suite with 100% pass rate'],
  ['Deployment', 'PM2 Cluster configuration, Nginx reverse proxy template, and SSL guide']
];

let rowY = tableTop + 18;
rows.forEach((r, idx) => {
  const bg = idx % 2 === 0 ? '#FFFFFF' : LIGHT_BG;
  doc.rect(45, rowY, 505, 16).fill(bg).stroke(BORDER_COLOR);
  doc.fillColor(MAROON).font('Helvetica-Bold').fontSize(8.5).text(r[0], 55, rowY + 4, { width: 100 });
  doc.fillColor(DARK_TEXT).font('Helvetica').fontSize(8.5).text(r[1], 155, rowY + 4, { width: 385 });
  rowY += 16;
});

// Add Page Footers
const range = doc.bufferedPageRange();
for (let i = range.start; i < range.start + range.count; i++) {
  doc.switchToPage(i);
  
  // Footer rule
  doc.strokeColor(BORDER_COLOR).lineWidth(0.5).moveTo(45, 790).lineTo(550, 790).stroke();
  
  // Footer text
  doc.fillColor(MUTED_TEXT)
     .font('Helvetica')
     .fontSize(8)
     .text('© 2026 Drodul Phendey Ling Foundation • Gelephu, Bhutan', 45, 796);
     
  doc.text(`Page ${i + 1} of ${range.count}`, 450, 796, { align: 'right', width: 100 });
}

doc.end();

writeStream.on('finish', () => {
  console.log(`✅ PDF Successfully Created: ${outputPath}`);
});
